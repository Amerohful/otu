package OTY;


import org.jfree.chart.*;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import javax.swing.*;
import java.awt.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

interface Influence {
    double g(double t);
}
enum dependenceType {
    K1("(k1/kзад)"), T3("(T1/T1зад)");
    private String title;
    dependenceType(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}

public class Main {
    private static double tau = 3.6351163881971404E-4;
    public static void main(String[] args) {
        JPanel panel = new JPanel();
        JFrame frame = new JFrame("Лабораторная работа №5");
        frame.setSize(600, 500);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        double w=634.9969, phi;
        phi = -3.14/2 - Math.atan((2*0.0014*0.5*w)/(1 - 0.0014*0.0014*635*635));
        //tau = (3.14 + phi)/635;
        System.out.println(phi);
        System.out.println(tau);
        Menu menu = new Menu();
        menu.items.add(new MenuItem("График амплитудно-фазовой частотной характеристики разомкнутой системы") {
            @Override
            public void run() {
                APFR(panel, frame);
            }
        });
        menu.items.add(new MenuItem("Посчитать графически критическое время запаздывания") {
            @Override
            public void run() {
                calcGraph(panel, frame);
            }
        });
        menu.items.add(new MenuItem("Моделирование") {
            @Override
            public void run() {
                menu.subMenu = new Menu();
                modelingChoice(menu.subMenu, panel, frame);
            }
        });
        menu.run();
        System.exit(0);
    }
    public static void  calcGraph(JPanel panel, JFrame frame) {
        GraphBuilder graphBuilder = new GraphBuilder(1700, 580, 0.0014, 0.5);
        JFreeChart chart = ChartFactory.createXYLineChart("Графическое нахождение критического времени запаздывания", "", "", graphBuilder.getCollection(), PlotOrientation.VERTICAL, true, true, true);
        clear(chart, panel, graphBuilder);

        graphBuilder.calcGraphically();

        XYPlot plot = chart.getXYPlot();
        graphBuilder.addAxes(0.2, 1, plot, "Re", "Im", true);
        XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, Color.black);
        renderer.setSeriesVisibleInLegend(0, false,true);
        renderer.setSeriesStroke(0, new BasicStroke(0.5f));
        repaint(chart, panel, frame);

    }
    public static void modeling(double  tau, JPanel panel, JFrame frame) {
        GraphBuilder graphBuilder = new GraphBuilder(0.25, 580, 0.0014, 0.5);
        JFreeChart chart = ChartFactory.createXYLineChart("Моделирование", "", "", graphBuilder.getCollection(), PlotOrientation.VERTICAL, true, true, true);
        clear(chart, panel, graphBuilder);

        graphBuilder.addGraph("С запаздыванием, tau = " + tau, tau);

        repaint(chart, panel, frame);
    }
    public static void APFR(JPanel panel, JFrame frame) {
        GraphBuilder graphBuilder = new GraphBuilder(1700, 580, 0.0014, 0.5);
        JFreeChart chart = ChartFactory.createXYLineChart("Критерий устойчивости Найквиста", "", "", graphBuilder.getCollection(), PlotOrientation.VERTICAL, true, true, true);
        clear(chart, panel, graphBuilder);
        graphBuilder.addAPFR("Амплитудно-фазовая частотная характеристика разомкнутой САР");

        XYPlot plot = chart.getXYPlot();
        graphBuilder.addAxes(0.1, 2, plot, "Re", "Im", false);

        repaint(chart, panel, frame);

    }  //построение АФЧХ

    private static void modelingChoice(Menu menu, JPanel panel, JFrame frame) {
        menu.items.add(new MenuItem("tau < tau критическое") {
            @Override
            public void run() {
                modeling(tau - 0.0002, panel, frame);
            }
        });
        menu.items.add(new MenuItem("tau = tau критическое") {
            @Override
            public void run() {
                modeling(tau, panel, frame);
            }
        });
        menu.items.add(new MenuItem("tau > tau критическое") {
            @Override
            public void run() {
                modeling(tau + 0.0002, panel, frame);
            }
        });
        menu.runAsSubMenu();
    }
    private static void clear(JFreeChart chart, JPanel panel, GraphBuilder graphBuilder) {
        XYPlot plot = chart.getXYPlot();
        if(panel.getComponentCount() != 0)
            panel.remove(panel.getComponent(0));
        graphBuilder.clear(plot);
    }
    private static void repaint(JFreeChart chart, JPanel panel, JFrame frame) {
        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.GRAY);
        panel.add(new ChartPanel(chart));
        panel.repaint();
        frame.setVisible(true);
        frame.setExtendedState(Frame.MAXIMIZED_BOTH);
    }
}
