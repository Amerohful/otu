package OTY;

import org.jfree.chart.annotations.XYTextAnnotation;
import org.jfree.chart.axis.Axis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.VectorSeries;
import org.jfree.data.xy.VectorSeriesCollection;
import org.jfree.data.xy.XYSeries;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

public class GraphBuilder {  //класс, строящий графики
    private final double dt = 0.000001;
    private double l, k, T, c, Xmax = 0, Ymax = 0, Xmin = Double.MAX_VALUE, Ymin = Double.MAX_VALUE;

    private VectorSeriesCollection collection;
    public GraphBuilder(double l, double k, double T, double c) {  //конструктор
        this.l = l;
        this.k = k;
        this.T = T;
        this.c = c;
        collection = new VectorSeriesCollection();
    }
    public void addGraph(String title, double tau) {
        double std = 0, x, g=1, y=0, y1=0, y2=0, z1=0, z2=0, k1, k2, k3, k4, m1, m2, m3, m4;
        int ns = (int) (tau/dt), i=0,j=0;
        System.out.println(ns);
        VectorSeries y_ser = new VectorSeries("Без запаздывания");
        VectorSeries delay_ser = new VectorSeries(title);
        while(std < l) {
            x = g - y;
            y1 += k*x*dt;
            y2 = z1;
            k1 = z2*dt;
            m1 = (-2*c/T*z2 - 1/(T*T)*z1 + y1/(T*T))*dt;
            k2 = (z2 + m1/2)*dt;
            m2 = (-2*c/T*(z2 + m1/2) - 1/(T*T)*(z1 + k1/2) + y1/(T*T))*dt;
            k3 = (z2 + m2/2)*dt;
            m3 = (-2*c/T*(z2 + m2/2) - 1/(T*T)*(z1 + k2/2) + y1/(T*T))*dt;
            k4 = (z2 + m3)*dt;
            m4 =  (-2*c/T*(z2 + m3) - 1/(T*T)*(z1 + k3) + y1/(T*T))*dt;

            z1 += (k1 + 2*k2 + 2*k3 + k4)/6;
            z2 += (m1 + 2*m2 + 2*m3 + m4)/6;

            y_ser.add(std, y2, 0, 0);

            if(i > ns) {
                y = y_ser.getYValue(i - ns);
            }
            else
                y = 0;
            i++;
            delay_ser.add(std, y, 0, 0);

            std += dt;
        }
        //collection.addSeries(y_ser);
        collection.addSeries(delay_ser);
    }
    /*

    private double getTh(VectorSeries series) {
        double th=0, y;
        int itemsCount = series.getItemCount();
        for(int i=0;i<itemsCount;i++) {
            y = series.getYValue(i);
            if(y <= 1.05 && y >= 0.95) {
                th = series.getXValue(i);
                break;
            }
        }
        return  th;
    }
    private double getTp(VectorSeries series, int index) {
        double tp=0, y;
        int itemsCount = series.getItemCount();
        boolean entered = false;
        for(int i=0;i<itemsCount;i++) {
            y = series.getYValue(i);
            if(y <= 1.05 &&  y >= 0.95) {
                if(!entered) {
                    tp = series.getXValue(i);
                    index = i;
                    entered = true;
                }
            }
            else
                entered = false;

            if(y == 0.95)
                System.out.println(tp);
        }
        return  tp;
    }

    public void addGraph(String title, Influence influence, double f1, double f2) {
        double std = 0, x, y=0, y1=0, y2=0;
        VectorSeries y_ser = new VectorSeries(title);
        while(std < l) {
            x = influence.g(std) - y;
            y1 += getY(1/T1, k1/T1, x, y1);
            y2 += getY(0, k2, y1+f1, y2);
            y += getY(1/T3, k3/T3, y2+f2, y);

            y_ser.add(std, y, 0, 0);
            std += dt;
        }
        collection.addSeries(y_ser);
    }
    public void addGraph(String title, String influence_title, Influence influence) {
        double std = 0, x, y=0, y1=0, y2=0, test1=0, test2, test3=0;
        VectorSeries y_ser = new VectorSeries(title);
        VectorSeries inf_ser = new VectorSeries(influence_title);
        while(std < l) {
            x = influence.g(std) - y;
            y1 += getY(1/T1, k1/T1, x, y1);
            y2 += getY(0, k2, y1, y2);
            y += getY(1/T3, k3/T3, y2, y);
            test1 = (1-y);
            test2 = test1*test1;
            test3 += test2*dt;
            System.out.println("x = " + test1);
            System.out.println("x^2 = " + test2);
            y_ser.add(std, y, 0, 0);
            inf_ser.add(std, influence.g(std), 0, 0);
            std += dt;
        }
        System.out.println("Integr: " + test3);
        if(influence_title.equals("g(t) = 1(t)*t") || influence_title.equals("g(t) = 1(t)")) {
            System.out.println("Установившаяся ошибка = " + Double.toString(inf_ser.getYValue(inf_ser.getItemCount() - 1) - y_ser.getYValue(y_ser.getItemCount()-1)));
            double max = inf_ser.getYValue(inf_ser.getItemCount() - 1) - y_ser.getYValue(y_ser.getItemCount()-1);
            for(int i=0; i<inf_ser.getItemCount();i++) {
                if(inf_ser.getYValue(i) - y_ser.getYValue(i) > max );
                    max = inf_ser.getYValue(i) - y_ser.getYValue(i);
            }
            System.out.println("Установившаяся ошибка = " + max);
        }
        collection.addSeries(y_ser);
        collection.addSeries(inf_ser);
    }

    public void addDeviation(String title) {
        double mis=0, dev, std = 0, g=1, x, y=0, y1=0, y2=0;
        VectorSeries dev_ser = new VectorSeries(title);
        VectorSeries test = new VectorSeries("x^2");
        while(std < l) {
            x = 1 - y;
            y1 += getY(1/T1, k1/T1, x, y1);
            y2 += getY(0, k2, y1, y2);
            y += getY(1/T3, k3/T3, y2, y);

            dev = (1 - y);
            mis += dev * dev * dt;
            System.out.println(mis);
            dev_ser.add(std, dev, 0, 0);
            test.add(std, dev*dev, 0 ,0);
            std += dt;
        }
        collection.addSeries(dev_ser);
        collection.addSeries(test);
        System.out.println("Вычисленная интегральная оценка: " + mis);
        System.out.println("Интегральная оценка, полученная аналитически: 1.0679" );
        System.out.println("Погрешность в вычислении: " + (1.0679 - mis)/1.0679 * 100 + "%");
    }
    public void addQualityIndicators() {
            Influence influence = (t) -> 1;
            addGraph("h(t)", influence,0,0);
            VectorSeries upper_ind_ser = new VectorSeries("Область допустимых отклонений");
            VectorSeries lower_ind_ser = new VectorSeries(" ");
            VectorSeries h_ser = collection.getSeries(0);
            double tp, th, Yest;
            int index=0;
            determineRange(h_ser);
            tp = getTp(h_ser, index);
            th = getTh(h_ser);
            Yest = h_ser.getYValue(h_ser.getItemCount() - 1);

            upper_ind_ser.add(0, Ymax, 0, 0);
            upper_ind_ser.add(tp, Ymax, 0, 0);
            upper_ind_ser.add(tp, 1.05, 0, 0);
            upper_ind_ser.add(l, 1.05, 0, 0);
            lower_ind_ser.add(tp, 0, 0, 0);
            lower_ind_ser.add(tp, 0.95, 0, 0);
            lower_ind_ser.add(l, 0.95, 0, 0);

            System.out.println("Допустимое отклонение: +-0.05");
            System.out.println("Время переходного процесса: " + tp);
            System.out.println("Время нарастания: " + th);
            System.out.println("Статическая погрешность: " + Math.abs(Yest - 1));
            System.out.println("Перерегулирование: " + (Ymax-1)*100 + "%");
            collection.addSeries(upper_ind_ser);
            collection.addSeries(lower_ind_ser);
    }
    public void addDependences(dependenceType type) {
        VectorSeries Tp_ser = new VectorSeries("Tp" + type.getTitle());
        VectorSeries Th_ser = new VectorSeries("Th"  + type.getTitle());
        VectorSeries ov_ser = new VectorSeries("Sigma" + type.getTitle());
        VectorSeries error_ser = new VectorSeries("Delta" + type.getTitle());
        VectorSeries y_ser;
        double Tp, Th, overshoot, error;
        double[] k = {k1/1.75, k1/1.5, k1/1.25, k1, 1.25*k1, 1.5*k1, 1.75*k1};
        double[] T = {T3/1.75, T3/1.5, T3/1.25, T3, 1.25*T3, 1.5*T3, 1.75*T3};
        int index=0;
        Influence infulence = (t) -> 1;
        for(int i=0;i<4;i++){
            if(type == dependenceType.K1)
                setK1(k[i]);
            else
                setT3(T[i]);
            addGraph("some title", infulence,0,0);
            y_ser = collection.getSeries(0);
            collection.removeSeries(y_ser);
            determineRange(y_ser);
            Tp = getTp(y_ser, index);
            Th = getTh(y_ser);
            overshoot = (Ymax - 1) * 100;
            error = Math.abs(y_ser.getYValue(y_ser.getItemCount()-1) - 1);

            Tp_ser.add(k[i], Tp, 0,0);
            Th_ser.add(k[i], Th, 0, 0);
            ov_ser.add(k[i], overshoot, 0, 0);
            error_ser.add(k[i], error, 0, 0);
        }
        collection.addSeries(Tp_ser);
        collection.addSeries(Th_ser);
        collection.addSeries(ov_ser);
        collection.addSeries(error_ser);
    }
    public void addIntegrFunc() {
        VectorSeries int_ser = new VectorSeries("Интегральная оценка");
        Influence influence = (t) -> 1;
        addGraph("some title", influence,0,0);
        VectorSeries y_ser = collection.getSeries(0);
        collection.removeSeries(y_ser);
        double I, x, sum=0;
        for(int i=0;i<y_ser.getItemCount();i++) {
            x = 1-y_ser.getYValue(i);
            I = x*x*dt;
            sum += I;
            int_ser.add(y_ser.getXValue(i), sum, 0, 0);
        }
        System.out.println(sum);
        collection.addSeries(int_ser);
       /* double K=0.1, I;
        while(K < l) {
            I = (T1 + T3 + K*(T1*T1 + T1*T3 + T3*T3))/(2*K*(T1 + T3 - K*T1*T3));
            int_ser.add(K, I, 0, 0);
            K += 0.1;
        }
        determineRange(int_ser);

        for(int i=0; i<int_ser.getItemCount();i++) {
            if(int_ser.getYValue(i) == Ymin)
                K = int_ser.getXValue(i);
        }

    }
  */
    public void calcGraphically() {
        double t = 0, x, y, w = dt, A1, A2, ph1, ph2, Re, Im;
        VectorSeries circle_ser = new VectorSeries("Единичная окружность");
        VectorSeries APFR_ser = new VectorSeries("Амплитудно-фазовая частотная характеристика разомкнутой САР");
            while(t < 200) {
                x = Math.cos(t);
                y = Math.sin(t);
                circle_ser.add(x ,y, 0, 0);
                t += 0.01;
            }
        while (w < l) {
            A1 = 1 / (Math.sqrt(Math.pow(1 - T * T * w * w, 2) + Math.pow(2 * T * c * w, 2)));
            A2 = k / w;
            if (w <= 1 / T)
                ph1 = -Math.atan((2 * c * T * w) / (1 - T * T * w * w));
            else
                ph1 = -Math.atan((2 * c * T * w) / (1 - T * T * w * w)) - 3.14;
            ph2 = -3.14 / 2;
            Re = A1 * A2 * Math.cos(ph1 + ph2);
            Im = A1 * A2 * Math.sin(ph1 + ph2);
            if (Im > -6 && Im < 100) {
                APFR_ser.add(Re, Im, 0, 0);
                if(inCircle(Re, Im, circle_ser)) {
                    System.out.println("Критическая частота равна " + w);
                    System.out.println("Критическая фаза равна " + (ph1+ph2));
                    System.out.println("Критическое время запаздывания: " + (3.14 + ph1+ph2)/w);
                    System.out.println(ph1 + ph2);
                }
            }
            w += 0.01;
        }
        determineRange(APFR_ser);
        collection.addSeries(circle_ser);
        collection.addSeries(APFR_ser);
    }
    private boolean inCircle(double x, double y, VectorSeries circle_ser) {
        double bottomX, topX, bottomY, topY;
        for(int i=0;i<circle_ser.getItemCount();i++) {
            bottomX = circle_ser.getXValue(i) - circle_ser.getXValue(i)/10000;
            topX = circle_ser.getXValue(i) + circle_ser.getXValue(i)/10000;
            bottomY = circle_ser.getYValue(i) - circle_ser.getYValue(i)/10000;
            topY = circle_ser.getYValue(i) + circle_ser.getYValue(i)/10000;
            if(x < bottomX && x > topX) {
                if(y < bottomY && y > topY)
                    return  true;
            }
        }
        return  false;
    }
    public void addAPFR(String title) {
        double w = dt, A1, A2, ph1, ph2, Re, Im,Re1, Im1, tau = 0.008;
       // double tau = 3.635 * Math.pow(10, -4);
        VectorSeries APFR_ser = new VectorSeries(title);
        VectorSeries newAPFR_ser = new VectorSeries("С запаздыванием");
        while (w < l) {
            A1 = 1/(Math.sqrt(Math.pow(1 - T*T*w*w,2) + Math.pow(2*T*c*w, 2)));
            A2 = k/w;
            if(w <= 1/T)
                ph1 = -Math.atan((2*c*T*w)/(1 - T*T*w*w));
            else
                ph1 = -Math.atan((2*c*T*w)/(1 - T*T*w*w)) - 3.14;
            ph2 = - 3.14/2;
            Re = A1*A2 * Math.cos(ph1 + ph2);
            Im = A1*A2 * Math.sin(ph1 +ph2);
            Re1 = A1*A2 * Math.cos(ph1 + ph2 - tau*w);
            Im1 = A1*A2 * Math.sin(ph1 + ph2 - tau*w);
            if(Im > -20 && Im < 100)
                APFR_ser.add(Re, Im, 0, 0);
            if(Im1 > -20 && Im1 < 100 && Re1 < 100 && Re1 > -100)
               newAPFR_ser.add(Re1, Im1, 0, 0);
            w += dt;
        }
        determineRange(APFR_ser);
        collection.addSeries(APFR_ser);
       // collection.addSeries(newAPFR_ser);
    }


    private void determineRange(VectorSeries series) {
        int itemsCount = series.getItemCount();
        double currentXValue, currentYValue;
        for(int i=0; i<itemsCount; i++) {
            currentXValue = series.getXValue(i);
            currentYValue = series.getYValue(i);

            if(currentXValue > Xmax)
                Xmax = Math.ceil(currentXValue);
            else if(currentXValue < Xmin)
                Xmin = Math.ceil(currentXValue);
            if(currentYValue > Ymax)
                Ymax = Math.ceil(currentYValue);
            else if(currentYValue < Ymin)
                Ymin = Math.ceil(currentYValue);
        }
    }

    public void addAxes(double dx, double dy, XYPlot plot, String xAsixLabel, String yAsixLabel, boolean ScaleAtTheMaxValue) {
        if (ScaleAtTheMaxValue) {
            if(Math.abs(Xmax) > Math.abs(Xmin))
                Xmin = -Math.ceil(Xmax);
            else
                Xmax = (int)-Math.ceil(Xmin);
            if(Math.abs(Ymax) > Math.abs(Ymin))
                Ymin = -Math.ceil(Ymax);
            else
                Ymax = -Math.ceil(Ymin);
        }
        addXaxis(dx);
        addYaxis(dy);
        addXlabels(plot, dx, dy, xAsixLabel);
        addYlabels(plot, dx, dy, yAsixLabel);

        XYLineAndShapeRenderer renderer = (XYLineAndShapeRenderer) plot.getRenderer();
        renderer.setSeriesPaint(collection.getSeriesCount()-1, Color.BLACK);
        renderer.setSeriesPaint(collection.getSeriesCount()-2, Color.BLACK);
        renderer.setSeriesVisibleInLegend(collection.getSeriesCount()-1, false, true);
        renderer.setSeriesVisibleInLegend(collection.getSeriesCount()-2, false, true);
        Axis axis = plot.getDomainAxis();
        axis.setTickLabelsVisible(false);
        NumberAxis na = (NumberAxis) plot.getRangeAxis();
        na.setVisible(false);

    }
    private void addXaxis(double dx) {
        VectorSeries Xaxis = new VectorSeries("x");
        Xaxis.add(Xmin-dx/2,0,0,0);
        Xaxis.add(Xmax+dx/2,0,0,0);
        collection.addSeries(Xaxis);
    }
    private void addYaxis(double dy) {
        VectorSeries Yaxis = new VectorSeries("y");
        Yaxis.add(0, Ymin-dy/2, 0, 0);
        Yaxis.add(0, Ymax+dy/2, 0, 0);
        collection.addSeries(Yaxis);
    }
    private void addXlabels(XYPlot plot, double dx, double dy, String xAsixLabel) {
        double x = round(Xmin + Math.abs(Xmin % dx),3);
        String str;
        while(x <= Xmax) {
            if(dx % 1 == 0)
                str = Integer.toString((int) x);
            else
                str = Double.toString(x);

            if(x == 0)
                plot.addAnnotation(new XYTextAnnotation(str, dx/5, -dy/3));
            else
                plot.addAnnotation(new XYTextAnnotation(str, x, -dy/3));
                x = round(x, 3) + round(dx, 3);
                x = round(x, 3);
        }
        plot.addAnnotation(new XYTextAnnotation(xAsixLabel, x-dx/4, -dy/3));
    }
    private void addYlabels(XYPlot plot, double dx, double dy, String yAsixLabel) {
        double y = Ymin + Math.abs(Ymin % dy);
        String str;
        while(y <= Ymax) {
            if(dy % 1 == 0)
                str = Integer.toString((int) y);
            else
                str = Double.toString(y);

            if (y != 0)
                plot.addAnnotation(new XYTextAnnotation(str, dx/5, y));
            y += dy;
        }
        plot.addAnnotation(new XYTextAnnotation(yAsixLabel, dx/5, y-dy/4));
    }
    private double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(Double.toString(value));
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
    public void clear(XYPlot plot) {
        collection.removeAllSeries();
        plot.getAnnotations().clear();
    }

    public VectorSeriesCollection getCollection() { return collection; }
    private void setK(double k) {
        this.k = k;
    }
    private void setT(double T) {
        this.T = T;
    }
}
